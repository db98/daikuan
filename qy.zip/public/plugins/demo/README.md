ThinkCMF 插件演示
===============

### 加载第三方库
支持使用`composer`加载第三方库
```
composer require phpoffice/phpspreadsheet
```