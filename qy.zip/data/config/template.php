<?php	return array (
  'cmf_default_theme' => 'adsw',
  'cmf_admin_default_theme' => 'admin_simpleboot3',
);