<?php	return array (
  '产品中心/:id' => 
  array (
    0 => 'portal/Article/index?cid=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
      'cid' => '\\d+',
    ),
  ),
  '新闻中心/:id' => 
  array (
    0 => 'portal/Article/index?cid=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
      'cid' => '\\d+',
    ),
  ),
  '企业咨询/:id' => 
  array (
    0 => 'portal/Article/index?cid=3',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
      'cid' => '\\d+',
    ),
  ),
  '荣誉资质/:id' => 
  array (
    0 => 'portal/Article/index?cid=4',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
      'cid' => '\\d+',
    ),
  ),
  '公司简介/:id' => 
  array (
    0 => 'portal/Article/index?cid=5',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
      'cid' => '\\d+',
    ),
  ),
  '行业动态/:id' => 
  array (
    0 => 'portal/Article/index?cid=6',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
      'cid' => '\\d+',
    ),
  ),
  '经典案例/:id' => 
  array (
    0 => 'portal/Article/index?cid=7',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
      'cid' => '\\d+',
    ),
  ),
  '艾维三德' => 
  array (
    0 => 'portal/Page/index?id=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
  '产品中心' => 
  array (
    0 => 'portal/List/index?id=1',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
  '新闻中心' => 
  array (
    0 => 'portal/List/index?id=2',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
  '企业咨询' => 
  array (
    0 => 'portal/List/index?id=3',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
  '荣誉资质' => 
  array (
    0 => 'portal/List/index?id=4',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
  '公司简介' => 
  array (
    0 => 'portal/List/index?id=5',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
  '行业动态' => 
  array (
    0 => 'portal/List/index?id=6',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
  '经典案例' => 
  array (
    0 => 'portal/List/index?id=7',
    1 => 
    array (
    ),
    2 => 
    array (
      'id' => '\\d+',
    ),
  ),
);