<?php /*a:6:{s:54:"D:\dmh\qy\public/themes/simpleboot3/portal\\index.html";i:1560949998;s:52:"D:\dmh\qy\public/themes/simpleboot3/public\head.html";i:1560935475;s:56:"D:\dmh\qy\public/themes/simpleboot3/public\function.html";i:1559860650;s:51:"D:\dmh\qy\public/themes/simpleboot3/public\nav.html";i:1560995826;s:54:"D:\dmh\qy\public/themes/simpleboot3/public\footer.html";i:1560950015;s:55:"D:\dmh\qy\public/themes/simpleboot3/public\scripts.html";i:1559860650;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>首页 <?php echo (isset($site_info['site_name']) && ($site_info['site_name'] !== '')?$site_info['site_name']:''); ?></title>
    <meta name="keywords" content="<?php echo (isset($site_info['site_seo_keywords']) && ($site_info['site_seo_keywords'] !== '')?$site_info['site_seo_keywords']:''); ?>"/>
    <meta name="description" content="<?php echo (isset($site_info['site_seo_description']) && ($site_info['site_seo_description'] !== '')?$site_info['site_seo_description']:''); ?>">
    
<?php 
    /*可以加多个方法哟！*/
    if (!function_exists('_sp_helloworld')) {
        function _sp_helloworld(){
        echo "hello ThinkCMF!";
        }
    }

    if (!function_exists('_sp_helloworld2')) {
        function _sp_helloworld2(){
        echo "hello ThinkCMF2!";
        }
    }

    if (!function_exists('_sp_helloworld3')) {
        function _sp_helloworld3(){
        echo "hello ThinkCMF3!";
        }
    }
 ?>
<meta name="author" content="ThinkCMF">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

<!-- Set render engine for 360 browser -->
<meta name="renderer" content="webkit">

<!-- No Baidu Siteapp-->
<meta http-equiv="Cache-Control" content="no-siteapp"/>

<!-- HTML5 shim for IE8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<![endif]-->
<link rel="icon" href="/themes/simpleboot3/public/assets/images/favicon.png" type="image/png">
<link rel="shortcut icon" href="/themes/simpleboot3/public/assets/images/favicon.png" type="image/png">
<link href="/themes/simpleboot3/public/assets/simpleboot3/themes/simpleboot3/bootstrap.min.css" rel="stylesheet">
<link href="/themes/simpleboot3/public/assets/simpleboot3/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet"
      type="text/css">
<!--[if IE 7]>
<link rel="stylesheet" href="/themes/simpleboot3/public/assets/simpleboot3/font-awesome/4.4.0/css/font-awesome-ie7.min.css">
<![endif]-->
<link href="/themes/simpleboot3/public/assets/css/style.css" rel="stylesheet">
<link href="/themes/simpleboot3/public/assets/css/style.css" rel="stylesheet">
<link href="/static/style/css/j_animate.css" rel="stylesheet">
<link href="/static/style/css/j_reset.css" rel="stylesheet">
<link href="/static/style/css/j_web.css" rel="stylesheet">
<!--<link href="/static/style/css/shchj.css" rel="stylesheet">-->

<style>
    /*html{filter:progid:DXImageTransform.Microsoft.BasicImage(grayscale=1);-webkit-filter: grayscale(1);}*/
    #backtotop {
        position: fixed;
        bottom: 50px;
        right: 20px;
        display: none;
        cursor: pointer;
        font-size: 50px;
        z-index: 9999;
    }

    #backtotop:hover {
        color: #333
    }

    #main-menu-user li.user {
        display: none
    }
</style>
<script type="text/javascript">
    //全局变量
    var GV = {
        ROOT: "/",
        WEB_ROOT: "/",
        JS_ROOT: "static/js/"
    };
</script>
<script src="/themes/simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
<script src="/themes/simpleboot3/public/assets/js/jquery-migrate-1.2.1.js"></script>
<script src="/static/style/js/j_animate.js"></script>
<script src="/static/style/js/j_div_scoll.js"></script>
<script src="/static/style/js/j_ijr.js"></script>
<script src="/static/style/js/j_reset.js"></script>
<script src="/static/style/js/j_web.js"></script>
<script src="/static/style/js/jquery-1.9.1.min.js"></script>

	
    <link href="/themes/simpleboot3/public/assets/css/slippry/slippry.css" rel="stylesheet">
    <style>
        .caption-wraper {
            position: absolute;
            left: 50%;
            bottom: 2em;
        }

        .caption-wraper .caption {
            position: relative;
            left: -50%;
            background-color: rgba(0, 0, 0, 0.54);
            padding: 0.4em 1em;
            color: #fff;
            -webkit-border-radius: 1.2em;
            -moz-border-radius: 1.2em;
            -ms-border-radius: 1.2em;
            -o-border-radius: 1.2em;
            border-radius: 1.2em;
        }

        .tc-gridbox {
            margin: 0;
        }

        @media (max-width: 767px) {
            .caption-wraper {
                left: 0;
                bottom: 0.4em;
            }

            .caption-wraper .caption {
                left: 0;
                padding: 0.2em 0.4em;
                font-size: 0.92em;
                -webkit-border-radius: 0;
                -moz-border-radius: 0;
                -ms-border-radius: 0;
                -o-border-radius: 0;
                border-radius: 0;
            }
        }

    </style>
    <?php 
    \think\facade\Hook::listen('before_head_end',null,false);
 ?>
</head>
<body class="body-white">
<header id="header" aos="fade-down" aos-duration="1000" class="aos-init aos-animate">
    <div class="main_box">

        <div id="logo_area"> <a href="http://www.js-mat.com" title=""><img src="/static/style/images/logo.png" alt=""></a> </div>
        <div class="right_box">
            <aside id="top_tel">
                咨询热线：  <strong>  029-63372618</strong>
            </aside>
            <aside id="text_welcome">
                欢迎来到<?php echo $site_info['site_name']; ?>官方网站！
            </aside>
            <div id="nav">
                <div class="">
                    <ul>
                        <?php
/*start*/
if (!function_exists('__parse_navigation_2b276ba91756538dfb31d68d388d6c60')) {
    function __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus,$level=1){
        $_parse_navigation_func_name = '__parse_navigation_2b276ba91756538dfb31d68d388d6c60';
if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): if( count($menus)==0 ) : echo "" ;else: foreach($menus as $key=>$menu): if(empty($menu['children'])): ?>
    
                                <li class="on"><a href="<?php echo (isset($menu['href']) && ($menu['href'] !== '')?$menu['href']:''); ?>" title="" class="a"><strong><?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?></strong><span><i></i></span></a></li>
                            
<?php endif; ?>

                        
        <?php endforeach; endif; else: echo "" ;endif; 
    }
}
/*end*/
    $navMenuModel = new \app\admin\model\NavMenuModel();
    $menus = $navMenuModel->navMenusTreeArray('0',0);
if('ul'==''): ?>
    <?php echo __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus); else: ?>
    <ul id="" class="nav navbar-nav">
        <?php echo __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus); ?>
    </ul>
<?php endif; ?>

                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <div class="clear"></div>
        </if>
    </div>
</header>




<ul id="home-slider" class="list-unstyled">
    <?php 
        $top_slide_id=empty($theme_vars['top_slide'])?1:$theme_vars['top_slide'];
          $__SLIDE_ITEMS__ = \app\admin\service\ApiService::slides($top_slide_id);
if(is_array($__SLIDE_ITEMS__) || $__SLIDE_ITEMS__ instanceof \think\Collection || $__SLIDE_ITEMS__ instanceof \think\Paginator): $i = 0; $__LIST__ = $__SLIDE_ITEMS__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

        <li>
            <div class="caption-wraper">
                <!--<div class="caption"><?php echo (isset($vo['title']) && ($vo['title'] !== '')?$vo['title']:''); ?></div>-->
            </div>
            <a href="<?php echo (isset($vo['url']) && ($vo['url'] !== '')?$vo['url']:''); ?>"><img src="<?php echo cmf_get_image_url($vo['image']); ?>" alt=""></a>
        </li>
    
<?php endforeach; endif; else: echo "" ;endif;     if(!isset($__SLIDE_ITEMS__)){
        $__SLIDE_ITEMS__ = \app\admin\service\ApiService::slides($top_slide_id);
    }
if(count($__SLIDE_ITEMS__) == 0): ?>

        <li>
            <div class="caption-wraper">
                <div class="caption">此幻灯片只是演示,您没有设置任何幻灯片,请到后台模板设置！</div>
            </div>
            <a href=""><img src="/themes/simpleboot3/public/assets/images/demo/1.jpg" alt=""></a>
        </li>

    
<?php endif; ?>
</ul>

<div class="container">
    <?php
     if(isset($theme_widgets['features']) && $theme_widgets['features']['display']){
        $widget=$theme_widgets['features'];
     
 ?>

        <div class="s_title aos-init aos-animate" aos="fade-up" aos-duration="1000">
            <h1 class="text-center"><?php echo $widget['title']; ?></h1>
            <h3 class="text-center"><?php echo $widget['vars']['sub_title']; ?></h3>
        </div>
        <?php 
            $features_count = count($widget['vars']['features']);
            $rows = ceil($features_count/3);
         $__FOR_START_23841__=1;$__FOR_END_23841__=$rows;for($row=$__FOR_START_23841__;$row <= $__FOR_END_23841__;$row+=1){ 
                $first_row = ($row-1)*3;
                $features = array_slice($widget['vars']['features'],$first_row,3);
             ?>
            <div class="row">
                <?php if(is_array($features) || $features instanceof \think\Collection || $features instanceof \think\Paginator): if( count($features)==0 ) : echo "" ;else: foreach($features as $key=>$vo): ?>
                    <div class="pic_box">
                        <img src="<?php echo $vo['icon']; ?>" alt="<?php echo $vo['content']; ?>">
                        <!--<h2 class="font-large nospace"><i class="fa fa-<?php echo $vo['icon']; ?>"></i> <?php echo $vo['title']; ?></h2>-->
                        <!--<h1><?php echo $vo['content']; ?></h1>-->
                        <p><?php echo $vo['content']; ?></p>
                    </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        <?php }     }
      if(isset($theme_widgets['last_news']) && $theme_widgets['last_news']['display']){
        $widget=$theme_widgets['last_news'];
     
 ?>

        <div>
            <h1 class="text-center"><?php echo $widget['title']; ?></h1>
        </div>

        <div class="row">
            <?php 
                $widget["vars"]["last_news_category_id"] = empty($widget["vars"]["last_news_category_id"])?1:$widget["vars"]["last_news_category_id"];
                $last_news_limit=4;
             $articles_data = \app\portal\service\ApiService::articles([
    'field'   => '',
    'where'   => "",
    'limit'   => $last_news_limit,
    'order'   => 'post.published_time DESC',
    'page'    => '',
    'relation'=> '',
    'category_ids'=>$widget['vars']['last_news_category_id']
]);

$__PAGE_VAR_NAME__ = isset($articles_data['page'])?$articles_data['page']:'';

 if(is_array($articles_data['articles']) || $articles_data['articles'] instanceof \think\Collection || $articles_data['articles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $articles_data['articles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                <div class="col-md-3">
                    <div class="tc-gridbox">
                        <div class="header">
                            <div class="item-image">
                                <a href="<?php echo cmf_url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>">
                                    <?php if(isset($vo['more']['thumbnail'])): if(empty($vo['more']['thumbnail']) || (($vo['more']['thumbnail'] instanceof \think\Collection || $vo['more']['thumbnail'] instanceof \think\Paginator ) && $vo['more']['thumbnail']->isEmpty())): ?>
                                            <img src="/themes/simpleboot3/public/assets/images/default-thumbnail.png"
                                                 class="img-responsive"
                                                 alt="">
                                            <?php else: ?>
                                            <img src="<?php echo cmf_get_image_url($vo['more']['thumbnail']); ?>"
                                                 class="img-responsive"
                                                 alt="">
                                        <?php endif; else: ?>
                                        <img src="/themes/simpleboot3/public/assets/images/default-thumbnail.png"
                                             class="img-responsive"
                                             alt="">
                                    <?php endif; ?>
                                </a>
                            </div>
                            <h3>
                                <a href="<?php echo cmf_url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>"><?php echo $vo['post_title']; ?></a>
                            </h3>
                            <hr>
                        </div>
                        <div class="body">
                            <p>
                                <a href="<?php echo cmf_url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>">...</a>
                            </p>
                        </div>
                    </div>
                </div>
            
<?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
    
<?php
    }
 ?>


    <!--<br>-->
<!--&lt;!&ndash; Footer ================================================== &ndash;&gt;-->
<!--<hr>-->
<!--<div id="footer">-->
    <!--<?php 
    \think\facade\Hook::listen('footer_start',null,false);
 ?>-->
    <!--<div class="links">-->
        <!--<?php
     $__LINKS__ = \app\admin\service\ApiService::links();
if(is_array($__LINKS__) || $__LINKS__ instanceof \think\Collection || $__LINKS__ instanceof \think\Paginator): $i = 0; $__LIST__ = $__LINKS__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
-->
            <!--<a href="<?php echo (isset($vo['url']) && ($vo['url'] !== '')?$vo['url']:''); ?>" target="<?php echo (isset($vo['target']) && ($vo['target'] !== '')?$vo['target']:''); ?>"><?php echo (isset($vo['name']) && ($vo['name'] !== '')?$vo['name']:''); ?></a>&nbsp;-->
        <!--
<?php endforeach; endif; else: echo "" ;endif; ?>-->

    <!--</div>-->
    <!--<p>-->
        <!--Made by <a href="http://www.thinkcmf.com" target="_blank">ThinkCMF</a>-->
        <!--Code licensed under the-->
        <!--<a href="http://www.apache.org/licenses/LICENSE-2.0" rel="nofollow" target="_blank">Apache License v2.0</a>.-->
        <!--<br/>-->
        <!--Based on-->
        <!--<a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>.-->
        <!--Icons from-->
        <!--<a href="http://fortawesome.github.com/Font-Awesome/" target="_blank">Font Awesome</a>-->
        <!--<br>-->
        <!--<?php if(!(empty($site_info['site_icp']) || (($site_info['site_icp'] instanceof \think\Collection || $site_info['site_icp'] instanceof \think\Paginator ) && $site_info['site_icp']->isEmpty()))): ?>-->
            <!--<a href="http://www.miitbeian.gov.cn/" target="_blank"><?php echo $site_info['site_icp']; ?></a>-->
            <!--<?php else: ?>-->
            <!--请在后台设置"网站信息"设置"ICP备"-->
        <!--<?php endif; ?>-->
        <!--<?php if(!(empty($site_info['site_gwa']) || (($site_info['site_gwa'] instanceof \think\Collection || $site_info['site_gwa'] instanceof \think\Paginator ) && $site_info['site_gwa']->isEmpty()))): ?>-->
            <!--<img src="/themes/simpleboot3/public/assets/images/ghs.png">-->
            <!--<a href="http://beian.gov.cn/" target="_blank"><?php echo $site_info['site_gwa']; ?></a>-->
            <!--<?php else: ?>-->
            <!--请在后台设置"网站信息"设置"公网安备"-->
        <!--<?php endif; ?>-->


    <!--</p>-->
<!--</div>-->
<!--<div id="backtotop">-->
    <!--<i class="fa fa-arrow-circle-up"></i>-->
<!--</div>-->


<footer id="footer" style="width: 100%">

    <div class="main_box">
        <section class="up_box">
            <div class="fot_left">
                <div id="fot_nav">
                    <a href="/chanpin/dumoshebei/">产品中心</a>
                    <a href="/zhaopin/">人才招聘</a>
                    <a href="/lianxi/">联系我们</a>
                </div>
                <div id="fot_contact">
                    <div class="p">
                        联系电话：029-88887071<br>

                        邮箱地址：gzlxjtu@opt.ac.cn   2497819416@qq.com<br>
                        公司地址：西安市经开区凤城二路海璟国际C2座1415室/西安市高新区西部大道60号                    <a href="/map.html" target="_blank" class="bnt_map">查看地图</a>

                    </div>
                </div>
                <div class="clear"></div>
            </div>

            <div id="fot_tel_box">
                <a href="tencent://message/?uin=909416052&amp;Site=QQ&amp;Menu=yes">在线咨询</a>
                <div class="clear"></div>
                <span>全国销售热线</span>
                <strong>029-88887071</strong>
            </div>
            <aside id="fot_ewm">
                <img src="/uploadfile/2018/0322/20180322102454152.png" alt="" class="ewm">

            </aside>
            <div class="clear"></div>
        </section>


    </div>
    <section class="un_box">
        <div class="main_box">
            <h1><p>COPYRIGHT©2018 西安钧盛新材料科技有限公司版权所有 ALL RIGHTS RESERVED 陕ICP备18002216号 网站建设：<a href="http://www.fgkj.cc" target="_blank" title="">凡高网络 </a></p> </h1>
        </div>
    </section>

</footer>
</div>
<!-- /container -->
<!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="/themes/simpleboot3/public/assets/simpleboot3/bootstrap/js/bootstrap.min.js"></script>
    <script src="/static/js/frontend.js"></script>
	<script>
	$(function(){
		$("#main-menu li.dropdown").hover(function(){
			$(this).addClass("open");
		},function(){
			$(this).removeClass("open");
		});
		
		$("#main-menu a").each(function() {
			if ($(this)[0].href == String(window.location)) {
				$(this).parentsUntil("#main-menu>ul>li").addClass("active");
			}
		});
		
		$.post("<?php echo url('user/index/isLogin'); ?>",{},function(data){
			if(data.code==1){
				if(data.data.user.avatar){
				}

				$("#main-menu-user span.user-nickname").text(data.data.user.user_nickname?data.data.user.user_nickname:data.data.user.user_login);
				$("#main-menu-user li.login").show();
                $("#main-menu-user li.offline").hide();

			}

			if(data.code==0){
                $("#main-menu-user li.login").hide();
				$("#main-menu-user li.offline").show();
			}

		});

        ;(function($){
			$.fn.totop=function(opt){
				var scrolling=false;
				return this.each(function(){
					var $this=$(this);
					$(window).scroll(function(){
						if(!scrolling){
							var sd=$(window).scrollTop();
							if(sd>100){
								$this.fadeIn();
							}else{
								$this.fadeOut();
							}
						}
					});
					
					$this.click(function(){
						scrolling=true;
						$('html, body').animate({
							scrollTop : 0
						}, 500,function(){
							scrolling=false;
							$this.fadeOut();
						});
					});
				});
			};
		})(jQuery); 
		
		$("#backtotop").totop();
		
		
	});
	</script>


<script src="/themes/simpleboot3/public/assets/js/slippry.min.js"></script>
<script>
    $(function () {
        $("#home-slider").slippry({
            transition: 'fade',
            useCSS: true,
            captions: false,
            speed: 1000,
            pause: 3000,
            auto: true,
            preload: 'visible'
        });
        $("#home-slider").show();
    });
</script>
<?php 
    \think\facade\Hook::listen('before_body_end',null,false);
 ?>
</body>
</html>
