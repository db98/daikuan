<?php /*a:6:{s:49:"D:\dmh\qy\public/themes/adsw/portal\\Dongtai.html";i:1561367377;s:45:"D:\dmh\qy\public/themes/adsw/public\head.html";i:1561189869;s:44:"D:\dmh\qy\public/themes/adsw/public\nav.html";i:1561004816;s:47:"D:\dmh\qy\public/themes/adsw/public\banner.html";i:1561020130;s:47:"D:\dmh\qy\public/themes/adsw/public\footer.html";i:1561343298;s:47:"D:\dmh\qy\public/themes/adsw/public\piaofu.html";i:1561031404;}*/ ?>
<!doctype html>
<html lang="zh-cmn-Hans"><head>
    <meta charset="utf-8">
    <!-- 技术支持：凡高网络 -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="renderer" content="webkit" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />

    <title>行业动态 - <?php echo (isset($theme_vars['name']) && ($theme_vars['name'] !== '')?$theme_vars['name']:'ThinkCMF'); ?></title>
    <meta name="keywords" content="<?php echo (isset($theme_vars['name']) && ($theme_vars['name'] !== '')?$theme_vars['name']:'ThinkCMF'); ?>">
    <meta name="description" content="<?php echo (isset($theme_vars['name']) && ($theme_vars['name'] !== '')?$theme_vars['name']:'ThinkCMF'); ?>">
    
<extend name="Public/base" />
<meta name="author" content="ThinkCMF">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="renderer" content="webkit">

<meta http-equiv="Cache-Control" content="no-siteapp"/>
<!--[if IE 7]>
<![endif]-->
<link href="/themes/adsw/public/assets/css/style.css" rel="stylesheet">
<link href="/themes/adsw/public/assets/css/style.css" rel="stylesheet">
<link href="/static/style/css/j_animate.css" rel="stylesheet">
<link href="/static/style/css/j_reset.css" rel="stylesheet">
<link href="/static/style/css/j_web.css" rel="stylesheet">
<!--<link href="/static/style/css/shchj.css" rel="stylesheet">-->


<script type="text/javascript">
    //全局变量
    var GV = {
        ROOT: "/",
        WEB_ROOT: "/",
        JS_ROOT: "static/js/"
    };
</script>
<script src="/static/style/js/j_animate.js"></script>
<script src="/static/style/js/j_div_scoll.js"></script>
<script src="/static/style/js/j_reset.js"></script>
<script src="/static/style/js/j_web.js"></script>
<script src="/static/style/js/jquery-1.9.1.min.js"></script>
<script src="/static/style/js/jquery-1.9.1.min.js"></script>
<script src="/static/style/js/j_ijr.js"></script>




    <!-- Compatible files -->

    <![endif]-->
    <script type="text/javascript">
        $(document).ready(function(){
            $("video").attr("poster","");
        });
    </script>
</head>

<body>
<div id="j_body">
    <!--=============================================header=============================================-->
    <header id="header" aos="fade-down" aos-duration="1000" class="aos-init aos-animate">
    <div class="main_box">

        <div id="logo_area"> <a href="http://www.js-mat.com" title=""><img src="/static/style/images/logo.png" width="417" height="110" alt=""></a> </div>
        <div class="right_box">
            <aside id="top_tel">
                咨询热线：  <strong>  029-63372618</strong>
            </aside>
            <aside id="text_welcome">
                欢迎来到<?php echo $site_info['site_name']; ?>官方网站！
            </aside>
            <div id="nav">
                <div class="">


                    <?php
/*start*/
if (!function_exists('__parse_navigation_2b276ba91756538dfb31d68d388d6c60')) {
    function __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus,$level=1){
        $_parse_navigation_func_name = '__parse_navigation_2b276ba91756538dfb31d68d388d6c60';
if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): if( count($menus)==0 ) : echo "" ;else: foreach($menus as $key=>$menu): if(empty($menu['children'])): ?>
    <li class="on">
    
                            <a href="<?php echo (isset($menu['href']) && ($menu['href'] !== '')?$menu['href']:''); ?>" target="<?php echo (isset($menu['target']) && ($menu['target'] !== '')?$menu['target']:''); ?>" class="a"><strong><?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?></strong></a>
                        
    </li>
<?php endif; ?>
                    
        <?php endforeach; endif; else: echo "" ;endif; 
    }
}
/*end*/
    $navMenuModel = new \app\admin\model\NavMenuModel();
    $menus = $navMenuModel->navMenusTreeArray('0',0);
if('ul'==''): ?>
    <?php echo __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus); else: ?>
    <ul id="" class="nav navbar-nav">
        <?php echo __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus); ?>
    </ul>
<?php endif; ?>


                </div>
            </div>
        </div>
        <div class="clear"></div>
        </if>
    </div>
</header>




    <!--====================banner-=======================-->

    <?php
     $__SLIDE_ITEMS__ = \app\admin\service\ApiService::slides(2);
if(is_array($__SLIDE_ITEMS__) || $__SLIDE_ITEMS__ instanceof \think\Collection || $__SLIDE_ITEMS__ instanceof \think\Paginator): $i = 0; $__LIST__ = $__SLIDE_ITEMS__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

<div id="n_banner" style="background:url(<?php echo cmf_get_image_url($vo['image']); ?>) center top no-repeat;"></div>

<?php endforeach; endif; else: echo "" ;endif; ?>

    <!--====================end banner====================-->
    <!--============================content============================= -->
    <section class="n_main_box">
        <div class="main_box">
            <section class="n_left">

                <div class="left_title">
                    <strong>news</strong>
                    <span>新闻中心</span>
                </div>
                <div id="n_nav">
                    <dl>
                        <dt  class="on"><a href="/portal/xinwen/">行业动态</a></dt>
                        <dt ><a href="/portal/xinwen/zizhi/">公司新闻</a></dt>
                    </dl>
                </div>

                <div id="left_links">
                    <a href="/portal/lianxi/" ><img src="/static/style/images/pic_left1.jpg"/><div class="icon_box"></div></a>

                </div>


            </section>    <section class="n_right">
            <section class="n_title">
                <h1>行业动态</h1>
                <div class="position">
                    <span>当前位置：</span> <a href="/" title="">首页</a> <i>&gt;</i> <a href="/">新闻中心</a> <i>&gt;</i> <em>行业动态</em>        </div>
            </section>

            <section class="n_content">
                <section id="n_news">
                    <ul>

                        <?php 
                        $category_ids=6;
                            $cid = 6;
                        $page=[
                        'list_rows'=>10,
                        'next'=>'下一页',
                        'prev'=>'上一页'
                        ];
                         $articles_data = \app\portal\service\ApiService::articles([
    'field'   => '',
    'where'   => "",
    'limit'   => '10',
    'order'   => 'post.published_time DESC',
    'page'    => $page,
    'relation'=> '',
    'category_ids'=>$category_ids
]);

$__PAGE_VAR_NAME__ = isset($articles_data['page'])?$articles_data['page']:'';

 if(is_array($articles_data['articles']) || $articles_data['articles'] instanceof \think\Collection || $articles_data['articles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $articles_data['articles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                            <li>
                                <div class="fl">
                                    <a href="<?php echo url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>" title="" target="_blank"><img src="<?php echo cmf_get_image_url($vo['more']['thumbnail']); ?>" alt="<?php echo $vo['post_title']; ?>"></a>
                                </div>
                                <div class="fr">
                                    <h1><a href="<?php echo url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>" title="<?php echo $vo['post_title']; ?>" target="_blank"><?php echo $vo['post_title']; ?></a><span><?php echo date('Y-m-d',!is_numeric($vo['create_time'])? strtotime($vo['create_time']) : $vo['create_time']); ?></span></h1>
                                    <p>
                                    <?php echo $vo['post_excerpt']; ?>
                                    </p>
                                </div>
                                <div class="clear"></div>
                            </li>
                        
<?php endforeach; endif; else: echo "" ;endif; ?>

                    </ul>
                    <div class="clear"></div>
                </section>
                <div class="clear"></div>

            </section>
        </section>
            <div class="clear"></div>
        </div>
    </section>


    <!--===============================footer====================================-->

    <!--<br>-->
<!--&lt;!&ndash; Footer ================================================== &ndash;&gt;-->
<!--<hr>-->
<!--<div id="footer">-->
    <!--<?php 
    \think\facade\Hook::listen('footer_start',null,false);
 ?>-->
    <!--<div class="links">-->
        <!--<?php
     $__LINKS__ = \app\admin\service\ApiService::links();
if(is_array($__LINKS__) || $__LINKS__ instanceof \think\Collection || $__LINKS__ instanceof \think\Paginator): $i = 0; $__LIST__ = $__LINKS__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
-->
            <!--<a href="<?php echo (isset($vo['url']) && ($vo['url'] !== '')?$vo['url']:''); ?>" target="<?php echo (isset($vo['target']) && ($vo['target'] !== '')?$vo['target']:''); ?>"><?php echo (isset($vo['name']) && ($vo['name'] !== '')?$vo['name']:''); ?></a>&nbsp;-->
        <!--
<?php endforeach; endif; else: echo "" ;endif; ?>-->

    <!--</div>-->
    <!--<p>-->
        <!--Made by <a href="http://www.thinkcmf.com" target="_blank">ThinkCMF</a>-->
        <!--Code licensed under the-->
        <!--<a href="http://www.apache.org/licenses/LICENSE-2.0" rel="nofollow" target="_blank">Apache License v2.0</a>.-->
        <!--<br/>-->
        <!--Based on-->
        <!--<a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>.-->
        <!--Icons from-->
        <!--<a href="http://fortawesome.github.com/Font-Awesome/" target="_blank">Font Awesome</a>-->
        <!--<br>-->
        <!--<?php if(!(empty($site_info['site_icp']) || (($site_info['site_icp'] instanceof \think\Collection || $site_info['site_icp'] instanceof \think\Paginator ) && $site_info['site_icp']->isEmpty()))): ?>-->
            <!--<a href="http://www.miitbeian.gov.cn/" target="_blank"><?php echo $site_info['site_icp']; ?></a>-->
            <!--<?php else: ?>-->
            <!--请在后台设置"网站信息"设置"ICP备"-->
        <!--<?php endif; ?>-->
        <!--<?php if(!(empty($site_info['site_gwa']) || (($site_info['site_gwa'] instanceof \think\Collection || $site_info['site_gwa'] instanceof \think\Paginator ) && $site_info['site_gwa']->isEmpty()))): ?>-->
            <!--<img src="/themes/adsw/public/assets/images/ghs.png">-->
            <!--<a href="http://beian.gov.cn/" target="_blank"><?php echo $site_info['site_gwa']; ?></a>-->
            <!--<?php else: ?>-->
            <!--请在后台设置"网站信息"设置"公网安备"-->
        <!--<?php endif; ?>-->


    <!--</p>-->
<!--</div>-->
<!--<div id="backtotop">-->
    <!--<i class="fa fa-arrow-circle-up"></i>-->
<!--</div>-->


<footer id="footer">

    <div class="main_box">
        <section class="up_box">
            <div class="fot_left">
                <div id="fot_nav">
                    <a href="/chanpin/dumoshebei/">产品中心</a>
                    <a href="/zhaopin/">人才招聘</a>
                    <a href="/lianxi/">联系我们</a>
                </div>
                <div id="fot_contact">
                    <div class="p">
                        联系电话：029-63372618<br>

                        邮箱地址：liuhaobo212@163.com<br>
                        公司地址：西安市高新区唐延南路东侧逸翠园-西安（二期）第1幢2单元3号房                    <a href="/portal/lianxi/map" target="_blank" class="bnt_map">查看地图</a>

                    </div>
                </div>
                <div class="clear"></div>
            </div>

            <div id="fot_tel_box">
                <a href="tencent://message/?uin=909416052&amp;Site=QQ&amp;Menu=yes">在线咨询</a>
                <div class="clear"></div>
                <span>全国销售热线</span>
                <strong>029-63372618</strong>
            </div>
            <aside id="fot_ewm">
                <img src="style/images/20180322102454152.png" alt="" class="ewm">

            </aside>
            <div class="clear"></div>
        </section>


    </div>
    <section class="un_box">
        <div class="main_box">
            <h1><p>COPYRIGHT©2018 <?php echo $site_info['site_name']; ?>版权所有 ALL RIGHTS RESERVED  </p> </h1>
        </div>
    </section>

</footer>

    <div class="piaofu" >
    <div class="box qq">
        <a href="tencent://message/?uin=909416052&Site=QQ&Menu=yes" title=""> </a>
    </div>

    <div class="box ewm_box">
        <a href="javascript:viod(0)" title=""> </a>
        <img class="ewm" src="style/images/20180322102454152.png" width="90" height="90"  />


    </div>
    <div class="box tel">
        <a href="JavaScript:;" title=""> </a>
        <div id="tel_box">  029-88887071</div>
    </div>

    <div class="box gotop">
        <a href="#header" id="gotop" title=""> </a>
    </div>
</div>

<script type="text/jscript" src="style/js/j_animate.js"></script>

<script language="JavaScript" src="/api.php?op=cnzzip"></script>
</body>
</html>


