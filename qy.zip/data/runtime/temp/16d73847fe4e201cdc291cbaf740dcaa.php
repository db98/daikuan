<?php /*a:5:{s:47:"D:\dmh\qy\public/themes/adsw/portal\\index.html";i:1561370617;s:45:"D:\dmh\qy\public/themes/adsw/public\head.html";i:1561189869;s:44:"D:\dmh\qy\public/themes/adsw/public\nav.html";i:1561004816;s:47:"D:\dmh\qy\public/themes/adsw/public\footer.html";i:1561370667;s:47:"D:\dmh\qy\public/themes/adsw/public\piaofu.html";i:1561370028;}*/ ?>
<!doctype html>
<html lang="zh-cmn-Hans"><head>
    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="renderer" content="webkit" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <title><?php echo $site_info['site_name']; ?>的网站</title>
    
<extend name="Public/base" />
<meta name="author" content="ThinkCMF">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="renderer" content="webkit">

<meta http-equiv="Cache-Control" content="no-siteapp"/>
<!--[if IE 7]>
<![endif]-->
<link href="/themes/adsw/public/assets/css/style.css" rel="stylesheet">
<link href="/themes/adsw/public/assets/css/style.css" rel="stylesheet">
<link href="/static/style/css/j_animate.css" rel="stylesheet">
<link href="/static/style/css/j_reset.css" rel="stylesheet">
<link href="/static/style/css/j_web.css" rel="stylesheet">
<!--<link href="/static/style/css/shchj.css" rel="stylesheet">-->


<script type="text/javascript">
    //全局变量
    var GV = {
        ROOT: "/",
        WEB_ROOT: "/",
        JS_ROOT: "static/js/"
    };
</script>
<script src="/static/style/js/j_animate.js"></script>
<script src="/static/style/js/j_div_scoll.js"></script>
<script src="/static/style/js/j_reset.js"></script>
<script src="/static/style/js/j_web.js"></script>
<script src="/static/style/js/jquery-1.9.1.min.js"></script>
<script src="/static/style/js/jquery-1.9.1.min.js"></script>
<script src="/static/style/js/j_ijr.js"></script>




    <link rel="shortcut icon" href="/favicon.ico"/>
    <!-- Style file -->
    <link rel="stylesheet" href="style/css/j_reset.css">
    <link rel="stylesheet" href="style/css/j_web.css">
    <link rel="stylesheet" href="style/css/j_animate.css">
    <script type="text/javascript" src="style/js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="style/js/j_reset.js"></script>
    <script type="text/javascript" src="style/js/j_web.js"></script>
    <script type="text/javascript" src="style/js/j_div_scoll.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){
            $("video").attr("poster","");
        });
    </script>
</head>

<body>
<div id="j_body">
    <!--=============================================header=============================================-->
    <header id="header" aos="fade-down" aos-duration="1000" class="aos-init aos-animate">
    <div class="main_box">

        <div id="logo_area"> <a href="http://www.js-mat.com" title=""><img src="/static/style/images/logo.png" width="417" height="110" alt=""></a> </div>
        <div class="right_box">
            <aside id="top_tel">
                咨询热线：  <strong>  029-63372618</strong>
            </aside>
            <aside id="text_welcome">
                欢迎来到<?php echo $site_info['site_name']; ?>官方网站！
            </aside>
            <div id="nav">
                <div class="">


                    <?php
/*start*/
if (!function_exists('__parse_navigation_2b276ba91756538dfb31d68d388d6c60')) {
    function __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus,$level=1){
        $_parse_navigation_func_name = '__parse_navigation_2b276ba91756538dfb31d68d388d6c60';
if(is_array($menus) || $menus instanceof \think\Collection || $menus instanceof \think\Paginator): if( count($menus)==0 ) : echo "" ;else: foreach($menus as $key=>$menu): if(empty($menu['children'])): ?>
    <li class="on">
    
                            <a href="<?php echo (isset($menu['href']) && ($menu['href'] !== '')?$menu['href']:''); ?>" target="<?php echo (isset($menu['target']) && ($menu['target'] !== '')?$menu['target']:''); ?>" class="a"><strong><?php echo (isset($menu['name']) && ($menu['name'] !== '')?$menu['name']:''); ?></strong></a>
                        
    </li>
<?php endif; ?>
                    
        <?php endforeach; endif; else: echo "" ;endif; 
    }
}
/*end*/
    $navMenuModel = new \app\admin\model\NavMenuModel();
    $menus = $navMenuModel->navMenusTreeArray('0',0);
if('ul'==''): ?>
    <?php echo __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus); else: ?>
    <ul id="" class="nav navbar-nav">
        <?php echo __parse_navigation_2b276ba91756538dfb31d68d388d6c60($menus); ?>
    </ul>
<?php endif; ?>


                </div>
            </div>
        </div>
        <div class="clear"></div>
        </if>
    </div>
</header>




    <!--====================banner-=======================-->

    <a name="n_yf" id="n_yf"></a>



    <!--=============================================header_end=============================================-->

    <section id="banner" aos="fade-up" aos-duration="1000">

        <div class="bd">

            <ul>
                <?php
     $__SLIDE_ITEMS__ = \app\admin\service\ApiService::slides(1);
if(is_array($__SLIDE_ITEMS__) || $__SLIDE_ITEMS__ instanceof \think\Collection || $__SLIDE_ITEMS__ instanceof \think\Paginator): $i = 0; $__LIST__ = $__SLIDE_ITEMS__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                    <li><a href="" title="" style="background:url(<?php echo cmf_get_image_url($vo['image']); ?>) center top no-repeat"></a></li>
                
<?php endforeach; endif; else: echo "" ;endif; ?>






            </ul>

        </div>



        <a href="javascript:void(0)" class="prev bnt"><img src="style/images/bnt_bn_prev.png" /></a>

        <a href="javascript:void(0)" class="next bnt"><img src="style/images/bnt_bn_next.png" /></a>



    </section>

    <div class="clear"></div>

    <!-------end banner--------->



    <!--=============================================content=============================================-->

    <div class="s_main_box">



        <section class="floor f1" id="s_pro">

            <div class="main_box">

                <div class="s_title" aos="fade-up" aos-duration="1000">



                    <h1>Product Center</h1>

                    <h2>产品中心</h2>



                </div>

                <div class="content" >



                    <div class="bd img_size">

                        <div class="section">

                            <ul aos="fade-up" aos-duration="1000">
                                <?php 
                                    $category_ids=1;
                                 $articles_data = \app\portal\service\ApiService::articles([
    'field'   => '',
    'where'   => "",
    'limit'   => '4',
    'order'   => 'post.published_time DESC',
    'page'    => '',
    'relation'=> '',
    'category_ids'=>$category_ids
]);

$__PAGE_VAR_NAME__ = isset($articles_data['page'])?$articles_data['page']:'';

 if(is_array($articles_data['articles']) || $articles_data['articles'] instanceof \think\Collection || $articles_data['articles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $articles_data['articles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                                    <li>

                                        <a href="<?php echo url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>">

                                            <div class="pic_box"><img src="<?php echo cmf_get_image_url($vo['more']['thumbnail']); ?>" alt="<?php echo $vo['post_title']; ?>"></div>

                                            <h1><?php echo $vo['post_title']; ?></h1>

                                        </a>

                                    </li>
                                
<?php endforeach; endif; else: echo "" ;endif; ?>
                                <div class="clear"></div>

                            </ul>

                            <a href="/chanpin/dumoshebei/" aos="fade-up" aos-duration="1000" class="more">查看更多</a>

                        </div>



                    </div>

                </div>



                <div class="clear"></div>

            </div>





        </section>

        <div class="floor f2" id="s_about">

            <div class="main_box">

                <div class="s_title" aos="fade-up" aos-duration="1000">

                    <h1>about us</h1>

                    <h2>关于我们</h2>



                </div>

                <div class="content img_size" aos="fade-up" aos-duration="1000">



                    <ul>

                        <li class="li1">

                            <div class="box">

                                <div class="pic_box">

                                    <img src="style/images/pic_s_about1.jpg" />

                                </div>



                            </div>

                        </li>

                        <li class="li2">

                            <div class="box">

                                <div class="pic_box">

                                    <img src="style/images/pic_s_about2.jpg" />

                                </div>



                            </div>

                        </li>

                        <li class="li3">

                            <div class="box">

                                <div class="pic_box">

                                    <img src="style/images/pic_s_about3.jpg" />

                                </div>



                            </div>

                        </li>

                        <li class="li4">

                            <div class="box">

                                <div class="text_box">

                                    <strong>introduce</strong>

                                    <span>公司简介</span>

                                    <a href="/guanyu/jianjie/" class="more">查看更多</a>

                                </div>

                            </div>

                        </li>

                        <li class="li5">

                            <div class="box">

                                <div class="pic_box">

                                    <img src="style/images/pic_s_about4.jpg" />

                                </div>

                            </div>

                        </li>

                        <li class="li6">

                            <div class="box">

                                <div class="text_box">

                                    <strong>honor</strong>

                                    <span>资质荣誉</span>

                                    <a href="/guanyu/zizhi/" class="more">查看更多</a>

                                </div>

                            </div>

                        </li>

                        <div class="clear"></div>

                    </ul>

                </div>



            </div>



        </div>

        <div class="floor f3" id="s_news">

            <div class="main_box">

                <div class="s_title" aos="fade-up" aos-duration="1000">

                    <h1>news center</h1>

                    <h2>新闻中心</h2>



                </div>

                <div class="hd" aos="fade-up" aos-duration="1000">

                    <a href="portal/xinwen/"><strong>行业动态</strong></a>

                    <a href="portal/xinwen/zizhi/" ><strong>企业资讯</strong></a>



                </div>

                <div class="content bd" aos="fade-up" aos-duration="1000">

                    <section class="section">

                        <ul>


                            <?php 
                                $category_ids=2;
                             $articles_data = \app\portal\service\ApiService::articles([
    'field'   => '',
    'where'   => "",
    'limit'   => '4',
    'order'   => 'post.published_time DESC',
    'page'    => '',
    'relation'=> '',
    'category_ids'=>$category_ids
]);

$__PAGE_VAR_NAME__ = isset($articles_data['page'])?$articles_data['page']:'';

 if(is_array($articles_data['articles']) || $articles_data['articles'] instanceof \think\Collection || $articles_data['articles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $articles_data['articles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                            <li> <a class="more" href="<?php echo url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>"><img src="<?php echo cmf_get_image_url($vo['more']['thumbnail']); ?>" alt="<?php echo $vo['post_title']; ?>" /><h1><?php echo $vo['post_title']; ?></h1></a>
                                <p>
                                    <?php echo $vo['post_excerpt']; ?>
                                    </p>

                                <div class="fot_box">

                                    <span><?php echo date('Y-m-d',!is_numeric($vo['create_time'])? strtotime($vo['create_time']) : $vo['create_time']); ?></span>

                                    <a href="/xinwen/hangye/72.html" class="more">更多..</a>

                                </div>

                            </li>
                            
<?php endforeach; endif; else: echo "" ;endif; ?>








                            <div class="clear"></div>

                        </ul>

                        <div class="more_box">

                            <a href="portal/xinwen/" class="more">查看更多</a>

                        </div>

                    </section>

                    <section class="section">

                        <ul>


                            <?php 
                                $category_ids=3;
                             $articles_data = \app\portal\service\ApiService::articles([
    'field'   => '',
    'where'   => "",
    'limit'   => '4',
    'order'   => 'post.published_time DESC',
    'page'    => '',
    'relation'=> '',
    'category_ids'=>$category_ids
]);

$__PAGE_VAR_NAME__ = isset($articles_data['page'])?$articles_data['page']:'';

 if(is_array($articles_data['articles']) || $articles_data['articles'] instanceof \think\Collection || $articles_data['articles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $articles_data['articles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>


                            <li> <a class="more" href="<?php echo url('portal/Article/index',array('id'=>$vo['id'],'cid'=>$vo['category_id'])); ?>"><img src="<?php echo cmf_get_image_url($vo['more']['thumbnail']); ?>" alt="<?php echo $vo['post_title']; ?>" /><h1><?php echo $vo['post_title']; ?></h1></a>

                                <p>

                                    <?php echo date('Y-m-d',!is_numeric($vo['create_time'])? strtotime($vo['create_time']) : $vo['create_time']); ?>
                                </p>

                                <div class="fot_box">

                                    <span>2018.09.12</span>

                                    <a href="/xinwen/gongsi/70.html" class="more">更多..</a>

                                </div>

                            </li>

                            
<?php endforeach; endif; else: echo "" ;endif; ?>


                            <div class="clear"></div>

                        </ul>

                        <div class="more_box">

                            <a href="portal/xinwen/zizhi/" class="more">查看更多</a>

                        </div>

                    </section>

                </div>

            </div>



        </div>



        <div class="floor f3" id="s_link_box" aos="fade-up" aos-duration="1000">



            <div class="main_box">

                <a class="fl" href="portal/lianxi/"><img src="style/images/pic_s_hr.png" alt=""></a>

                <a class="fr" href="portal/lianxi/"><img src="style/images/pic_s_contact.png" alt=""></a>

                <div class="clear"></div>

            </div>

        </div>

        <div class="floor f4" id="s_partner" aos="fade-up" aos-duration="1000">







            <section class="main_box">

                <div class="content">

                    <!--<div class="s_title" >-->

                        <!--<h1>合作机构</h1>-->

                        <!--<h2>Cooperation Agency</h2>-->

                    <!--</div>-->

                    <div class="bd">

                        <ul>



                            <!--<li>-->

                                <!--<a href="" target="_blank">-->

                                    <!--<img  src="style/images/20180308045748935.png" alt="西科天使基金" />-->

                                <!--</a>-->

                            <!--</li>-->




                            <!--<li>-->

                                <!--<a href="http://www.opt.ac.cn/" target="_blank">-->

                                    <!--<img  src="style/images/20180308045806429.png" alt="西安光机所" />-->

                                <!--</a>-->

                            <!--</li>-->




                            <!--<li>-->

                                <!--<a href="http://www.casstar.com.cn/web/home.do" target="_blank">-->

                                    <!--<img  src="style/images/20180308045823330.png" alt="中科创星" />-->

                                <!--</a>-->

                            <!--</li>-->




                            <!--<li>-->

                                <!--<a href="http://www.dtcap.com/cn/home.asp" target="_blank">-->

                                    <!--<img  src="style/images/20180308045839285.png" alt="徳同资本" />-->

                                <!--</a>-->

                            <!--</li>-->







                        </ul>

                    </div>

                    <div class="clear"></div>

                </div>

            </section>





        </div>







        <div class="clear"></div>





    </div>

    <!--============================footer============================= -->





    <!--===============================footer====================================-->
    <!--<br>-->
<!--&lt;!&ndash; Footer ================================================== &ndash;&gt;-->
<!--<hr>-->
<!--<div id="footer">-->
    <!--<?php 
    \think\facade\Hook::listen('footer_start',null,false);
 ?>-->
    <!--<div class="links">-->
        <!--<?php
     $__LINKS__ = \app\admin\service\ApiService::links();
if(is_array($__LINKS__) || $__LINKS__ instanceof \think\Collection || $__LINKS__ instanceof \think\Paginator): $i = 0; $__LIST__ = $__LINKS__;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
-->
            <!--<a href="<?php echo (isset($vo['url']) && ($vo['url'] !== '')?$vo['url']:''); ?>" target="<?php echo (isset($vo['target']) && ($vo['target'] !== '')?$vo['target']:''); ?>"><?php echo (isset($vo['name']) && ($vo['name'] !== '')?$vo['name']:''); ?></a>&nbsp;-->
        <!--
<?php endforeach; endif; else: echo "" ;endif; ?>-->

    <!--</div>-->
    <!--<p>-->
        <!--Made by <a href="http://www.thinkcmf.com" target="_blank">ThinkCMF</a>-->
        <!--Code licensed under the-->
        <!--<a href="http://www.apache.org/licenses/LICENSE-2.0" rel="nofollow" target="_blank">Apache License v2.0</a>.-->
        <!--<br/>-->
        <!--Based on-->
        <!--<a href="http://getbootstrap.com/" target="_blank">Bootstrap</a>.-->
        <!--Icons from-->
        <!--<a href="http://fortawesome.github.com/Font-Awesome/" target="_blank">Font Awesome</a>-->
        <!--<br>-->
        <!--<?php if(!(empty($site_info['site_icp']) || (($site_info['site_icp'] instanceof \think\Collection || $site_info['site_icp'] instanceof \think\Paginator ) && $site_info['site_icp']->isEmpty()))): ?>-->
            <!--<a href="http://www.miitbeian.gov.cn/" target="_blank"><?php echo $site_info['site_icp']; ?></a>-->
            <!--<?php else: ?>-->
            <!--请在后台设置"网站信息"设置"ICP备"-->
        <!--<?php endif; ?>-->
        <!--<?php if(!(empty($site_info['site_gwa']) || (($site_info['site_gwa'] instanceof \think\Collection || $site_info['site_gwa'] instanceof \think\Paginator ) && $site_info['site_gwa']->isEmpty()))): ?>-->
            <!--<img src="/themes/adsw/public/assets/images/ghs.png">-->
            <!--<a href="http://beian.gov.cn/" target="_blank"><?php echo $site_info['site_gwa']; ?></a>-->
            <!--<?php else: ?>-->
            <!--请在后台设置"网站信息"设置"公网安备"-->
        <!--<?php endif; ?>-->


    <!--</p>-->
<!--</div>-->
<!--<div id="backtotop">-->
    <!--<i class="fa fa-arrow-circle-up"></i>-->
<!--</div>-->


<footer id="footer">

    <div class="main_box">
        <section class="up_box">
            <div class="fot_left">
                <div id="fot_nav">
                    <a href="/portal/chanpin/">产品中心</a>
                    <a href="/portal/lianxi/">联系我们</a>
                </div>
                <div id="fot_contact">
                    <div class="p">
                        联系电话：029-63372618<br>

                        邮箱地址：liuhaobo212@163.com<br>
                        公司地址：西安市高新区唐延南路东侧逸翠园-西安（二期）第1幢2单元3号房                    <a href="/portal/lianxi/map" target="_blank" class="bnt_map">查看地图</a>

                    </div>
                </div>
                <div class="clear"></div>
            </div>

            <div id="fot_tel_box">
                <!--<a href="tencent://message/?uin=909416052&amp;Site=QQ&amp;Menu=yes">在线咨询</a>-->
                <div class="clear"></div>
                <span>全国销售热线</span>
                <strong>029-63372618</strong>
            </div>
            <aside id="fot_ewm">
                <img src="style/images/20180322102454152.png" alt="" class="ewm">

            </aside>
            <div class="clear"></div>
        </section>


    </div>
    <section class="un_box">
        <div class="main_box">
            <h1><p>COPYRIGHT©2018 <?php echo $site_info['site_name']; ?>版权所有 ALL RIGHTS RESERVED  </p> </h1>
        </div>
    </section>

</footer>

    <!--<div class="piaofu" >-->
    <!--<div class="box qq">-->
        <!--<a href="tencent://message/?uin=909416052&Site=QQ&Menu=yes" title=""> </a>-->
    <!--</div>-->

    <!--<div class="box ewm_box">-->
        <!--<a href="javascript:viod(0)" title=""> </a>-->
        <!--<img class="ewm" src="style/images/20180322102454152.png" width="90" height="90"  />-->


    <!--</div>-->
    <!--<div class="box tel">-->
        <!--<a href="JavaScript:;" title=""> </a>-->
        <!--<div id="tel_box">  029-88887071</div>-->
    <!--</div>-->

    <!--<div class="box gotop">-->
        <!--<a href="#header" id="gotop" title=""> </a>-->
    <!--</div>-->
<!--</div>-->

</div>
<script type="text/jscript" src="style/js/j_animate.js"></script>

<script language="JavaScript" src="/api.php?op=cnzzip"></script>
</body>
</html>


