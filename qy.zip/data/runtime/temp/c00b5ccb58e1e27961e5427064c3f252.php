<?php /*a:1:{s:59:"D:\dmh\qy\public/plugins/theme_design_demo/view/design.html";i:1559860650;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
模板设计自定义演示，开发者可以通过此插件优化后台模板设计功能
</body>
</html>