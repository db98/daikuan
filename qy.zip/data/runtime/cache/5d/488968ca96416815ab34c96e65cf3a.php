<?php
//000000000000
 exit();?>
think_serialize:O:16:"think\Collection":1:{s:8:" * items";a:1:{i:0;a:2:{s:4:"hook";s:23:"admin_theme_design_view";s:6:"plugin";s:15:"ThemeDesignDemo";}}}