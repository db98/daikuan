<?php
//000000000000
 exit();?>
think_serialize:a:8:{s:9:"site_name";s:12:"艾德三维";s:14:"site_seo_title";s:12:"艾德三维";s:17:"site_seo_keywords";s:12:"艾德三维";s:20:"site_seo_description";s:12:"艾德三维";s:8:"site_icp";s:16:"陕ICP1234567号";s:8:"site_gwa";s:16:"陕ICP1234567号";s:16:"site_admin_email";s:11:"jeib@qq.com";s:14:"site_analytics";s:0:"";}