<?php

use think\facade\Route;

Route::resource('demo/articles', 'demo/Articles');
